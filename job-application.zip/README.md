# JobApplication

### This is the repository for the frontend of [Acharya Job Application](https://acharyauniversity.github.io/JobApplication) web portal
